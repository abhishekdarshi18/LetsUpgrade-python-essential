altitude = int(input("hight:  "))

if altitude == 1000:
    massage="Safe to land"

elif altitude >1000 and altitude<5000:
   massage="Bring down to 1000ft"
   
else:
    massage="Turn around"
    
print(massage)