for num in range(1,200): 

    for number in range(2,num): 

        if(num % number==0): 

            break

    else: 

        print(num) 