sub_lst = [1,1,5]

def lst(lis):
    n=0
    count=0
    
    for item in sub_lst:
        for i in range(n,len(lis)):
            if item == lis[i]:
                n=i+1
                count+=1
                break
    if count == len(sub_lst):
            print('Its a Match')
    else:
        print('Its gone')      
        
              
lst([1,5,6,4,1,2,3,5])     

