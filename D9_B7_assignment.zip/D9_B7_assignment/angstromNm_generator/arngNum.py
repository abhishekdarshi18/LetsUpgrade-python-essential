#lower = 1
#upper = 1000
def angs_num(x,y):
    

    for num in range(x, y + 1):
    
       # order of number
       order = len(str(num))
        
       # initialize sum
       sum = 0
      
       temp = num
       

       while temp > 0:
           digit = temp % 10
           sum += digit ** order
           temp //= 10
                  
           
       if num == sum:
           print(num)
           
   

angs_num(int(input('Lower Number: ')),int(input('Upper Number: ')))
       